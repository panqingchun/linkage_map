#!/usr/bin/perl
#get the map index from the map.txt, and save it in the step6/seq.txt for use, also get the information of the snps tried in, and 
#save them in the step6/info_of_try_in.txt.
package new_perl::step6;

use autodie;
use strict;
use warnings;

my ($dir, $folder);
my ($in_try, $in_bin_info, $in_hebin);
my (@data_try, %data_bin_info, @data_try_in);
my ($out, $out_seq);
my $num_of_hebin;

sub new {
	my $class = shift;
	my $self  = bless { }, $class;
	return $self;
}

sub init {
	my $class = shift;

	$dir = shift;
	$folder = shift;

	open $in_try, '<', $dir.$folder."/try.map";
	open $in_bin_info, '<', $dir."step3/bin_info.txt";
	open $in_hebin, '<', $dir.$folder."/step4/hebin.txt";

	eval {mkdir $dir.$folder."/step6/"};
	open $out, '>', $dir.$folder."/step6/info_of_try_in.txt";
	open $out_seq, '>', $dir.$folder."/step6/seq.txt";

	@data_try = ();
	#%data_bin_info = {};
	@data_try_in = ();
	<$in_try>;
	while (<$in_try>){
		$_ =~ /\s*(\d*)\s*(\d*)\s*(\S*)\s*/;
		push @data_try,[($1, $2, $3)];
	}
	
	while (<$in_bin_info>){
		chomp;
		my @line = split "\t";
		$data_bin_info{$line[0]} = $_;
	}
	
	$num_of_hebin = 0;
	$num_of_hebin++ while <$in_hebin>;
}

sub main {
	my $class = shift;

	for (@data_try){
		print $out_seq ${$_}[1]." ";
		last if ${$_}[1] == $num_of_hebin;
		if (${$_}[1] > $num_of_hebin){
			print "${$_}[2]\n";
			push @data_try_in, ${$_}[2];
		}
	}
	#map {say $out, $data_bin_info{$_}} @data_try_in;
	map {say $out $data_bin_info{$_}} @data_try_in;	

	close $in_try, $in_bin_info, $in_hebin,$out, $out_seq;
}

1;	
