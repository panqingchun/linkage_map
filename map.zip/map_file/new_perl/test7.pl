#!/usr/bin/perl

use strict;
use autodie;


my $str1 = "/home/maizego/Desktop/chr1.raw";
my $str2 = "/home/maizego/Desktop/chr2.raw";
open my $in1, '<', $str1;
open my $in2 , '<', $str2;
open my $out1, '>', "out1";
open my $out2, '>', "out2";

close $out1, $out2 or die "cannot close $!";
