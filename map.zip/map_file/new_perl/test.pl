#!/usr/bin/perl
BEGIN{
push @INC, "H:";
push @INC, "/media/disk/";
}

use autodie;

$SIG{ILL}=\&term;

sub term{
	print "terming...\n";
}

my $pid = fork;
print "-------------$$--------------\n";
if ($pid > 0){
	foreach (1..6){
		$_+=-4;
		my $me = 8/$_;
		print "parent: $me...\n";
	}
}else{
	for (1){
	print "i am alive...\n";
	sleep 3;
}
}
waitpid($pid, 0);
