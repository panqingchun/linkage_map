#!/usr/bin/perl

use strict;
#use warnings;
use autodie;

my $qunti_num = shift;
my @qunti = qw(BB BK KC KD KUI3 MO17 SK ZONG3);

chdir "/media/文件/panqinchun/7_qunti/total_8_populations/";
open my $in_info, '<', "chr_info.csv";
open my $in_BK, '<', "$qunti[$qunti_num]/$qunti[$qunti_num].csv";
open my $out , '>', "$qunti[$qunti_num]/$qunti[$qunti_num]_chacuo.csv";



my %data_info;
<$in_info>;
while (<$in_info>){
	chomp;
	my @line = split ",";
	$data_info{$line[1]} = join ",", ($line[2],$line[3]);
}

my @data_BK;
my $title = <$in_BK>;
print $out "chr,pos,snp,".$title; 
while (<$in_BK>){
	chomp;
	my @line = split ",";
	print $out $data_info{$line[0]}.",".$_."\n";
}

close $in_info, $in_BK, $out;
