package new_perl::step1;


use 5.010;
use strict;
use warnings;

use File::Basename;


our $VERSION = '0.01';

sub new {
	my $class = shift;
	my $self  = bless { }, $class;
	return $self;
}

=pod

=head2 dummy

This method does something... apparently.

=cut

sub doit_1 {
	my $self = shift;

	my $fname = shift;
	print $fname."\n";
	
	my $dir = dirname($fname);
	mkdir $dir."/step1/" ;
	open my $in, '<', $fname or die "can't open the file $fname $!";
	open my $out1, '>', "$dir/step1/mat.csv" or die;
	open my $out2, '>', "$dir/step1/snp.csv" or die;
	my $title = <$in>;
	
	#print $title;
	
	chomp $title;
	my @title = split ",", $title;
	my @data;
	while (<$in>){
		#print $_;
		chomp;
		next if $_ eq "";		
		my @line = split ",";
		
		#print "@line\n";
		#print "$line[1]\t$line[2]\n";
		
		push @data, \@line if $line[1] eq $line[2] && $line[1] ne "--" && substr($line[1],0,1) eq substr($line[1],1,1);
	}
	#mat 
	my @mat_data; 
	for (my $i=3; $i<@title; $i++){
		my $count=0;
		for (my $j=0; $j<@data; $j++){
			$count++ if $data[$j][$i] ne $data[$j][1] && $data[$j][$i] ne "--" && substr($data[$j][$i],0,1) eq substr($data[$j][$i],1,1);
		}
		push @mat_data, [($title[$i] ,$count, $count/@data)];
	}
	print @mat_data."\n";
	#snp
	my @snp_data; 
	
	for (my $i=0; $i<@data; $i++){
		my $count=0;
		for (my $j=3; $j<@{$data[0]}; $j++){
			$count++ if $data[$i][$j] ne $data[$i][1] && $data[$i][$j] ne "--" && substr($data[$i][$j],0,1) eq substr($data[$i][$j],1,1);
		}
		push @snp_data, [($data[$i][0], $count, $count/(@{$data[0]}-3) )];
	}
	#print 
	map{print $out1 join ",", @{$_}; print $out1 "\n"} @mat_data; 
	map{print $out2 join ",", @{$_}; print $out2 "\n"} @snp_data; 

	close $in;
	close $out1;
	close $out2;
	
	return 1;
}


sub doit_2 {
	my $self = shift;

	my $fname = shift;
	say $fname;
	
	my $dir = dirname($fname);
	mkdir $dir."/step1/" ;
	open my $in, '<', $fname or die "can't open the file $fname $!";
	open my $out, '>', "$dir/step1/miss.csv" or die; 
	
	my $title = <$in>;
	chomp $title;
	my @title = split ",", $title;
	
	
	
	
	my @count = (0) x @title;
	my $count1 = 0;
	while (<$in>){
		next if $_ eq "";
		$count1++;
		chomp;
		my @line = split ",";
		map {$count[$_]++ if $line[$_] eq "--"} 1..$#line;
	}
	
	map {my $ratio = $count[$_]/$count1; say $out "$title[$_],$count[$_],$ratio"} 1..$#count; #### 
	
	close $in;
	close $out;
	
	return 1;
}

sub doit_3 {
	my $self = shift;

	my $fname = shift;
	say $fname;
	
	my $dir = dirname($fname);
	mkdir $dir."/step1/" ;
	open my $in, '<', $fname or die "can't open the file $fname $!";
	open my $out, '>', "$dir/step1/zahe.csv" or die; 
	
	my $title = <$in>;
	chomp $title;
	my @title = split ",", $title;
	my @count = (0) x @title;
	my $count1 = 0;
	while (<$in>){
		next if $_ eq "";
		$count1++;
		chomp;
		my @line = split ",";
		map {$count[$_]++ if substr($line[$_],0,1) ne substr($line[$_],1,1)} 1..$#line; 
	}
	
	map {my $ratio = $count[$_]/$count1;say $out "$title[$_],$count[$_],$ratio"} 1..$#count;
	
	close $in;
	close $out;
	
	return 1;
}







sub doit_4 {
	my $self = shift;

	my $fname_mat = shift;
	my $fname_miss = shift;
	my $fname_zahe = shift;
	
	my $dir = dirname($fname_mat);
	open my $in_mat, '<', $fname_mat or die "can't open the file $fname_mat $!";
	open my $in_miss, '<', $fname_miss or die "can't open the file $fname_miss $!";
	open my $in_zahe, '<', $fname_zahe or die "can't open the file $fname_zahe $!";
	open my $out, '>', "$dir/select.csv" or die;
	
	my %mat_name;
	
	########mat
	my @mat;
	
	while (<$in_mat>){
		chomp;
		push @mat, [split ","];
	}
	my $total_mat = 0;
	map {$total_mat += ${$_}[2]} @mat;
	my $avg_mat = $total_mat/@mat;
	my $sd = 0;
	my $tmp = 0;
	map {$tmp += (${$_}[2]-$avg_mat)*(${$_}[2]-$avg_mat)} @mat;
	$sd = sqrt($tmp/@mat);
	say $out "mat";  
	foreach (@mat){
		if (${$_}[2] > ($avg_mat + 2* $sd)){ 
			say $out ",".${$_}[0];
			$mat_name{${$_}[0]} = 1; 
		}
	} 

	
	#missing
	my @miss;
	<$in_miss>;
	<$in_miss>;
	while (<$in_miss>){
		chomp;
		push @miss, [split ","];
	}
	say $out "missing";
	foreach (@miss){ 
		if (${$_}[2] > 0.15){
			say $out ",".${$_}[0];
			$mat_name{${$_}[0]} = 1;
		}
	}
	
	
	#zahe
	my @zahe;
	<$in_zahe>;
	<$in_zahe>;
	while (<$in_zahe>){
		chomp;
		push @zahe, [split ","];
	}
	say $out "zahe";
	foreach (@zahe){
		if (${$_}[2] > 0.1){ 
			say $out ",".${$_}[0];
			$mat_name{${$_}[0]} = 1;
		}
	}
	#hebing
	say $out "hebing";
	foreach (keys %mat_name){
		say $out ",$_";
	}
	
	close $in_mat, $in_miss, $in_zahe, $out;
}
	
1;

