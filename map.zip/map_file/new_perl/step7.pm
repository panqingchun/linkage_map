#!/usr/bin/perl
#do flips for the last step's snps selected to make sure that they are correct,and get the finall map data, witch is saved in /step7/map_finall.txt.
package new_perl::step7;

use autodie;
use strict;
use warnings;
use IPC::Open2;


my ($dir,$folder);
my $seq;
my ($out, $out_log);
my $pid;

sub new {
	my $class = shift;
	my $self  = bless { }, $class;
	return $self;
}

if ($pid) {
	$SIG{INT} = \&final;
}
sub final {
	print "\nwait for exiting.........\n";
	print WRITE "exit\n";
	waitpid($pid,0);
	exit 0;
}

sub init {
	my $class = shift;

	$dir = shift;
	$folder = shift;

	eval {mkdir "$dir/$folder/step7/"};
	open my $in_seq, '<', $dir.$folder."/step6/seq.txt";
	chomp ($seq = <$in_seq>);
	open $out, '>', $dir.$folder."/step7/map_finall.txt";
	open $out_log, '>', $dir.$folder."/step7/log.txt";
}

sub main {
	my $class = shift;

	flips();
	
	close $out, $out_log;
}

sub flips {
	$pid = open2(*READ , *WRITE, 'carthagene 2>/dev/null');
	my @commands = (
	"dsload $dir/$folder/hebin_with_left.raw",
	"mrkselset {$seq}",
	'sem',
	'flips 7 1 0',
	'sem',
	'heaprintd',
	"exit",
	);
	my @data;
	for (0..$#commands){
		print $out_log "--------------$_------------------\n";
		my $count = $_;
		print WRITE $commands[$_]."\n";
		print WRITE "\n";
		print "this step will take much time , please be patient ...\n" if $count == 3;
		while (<READ>){
			chomp;
			say $out_log $_;
			last if $_ eq "CG> ";
			push @data, $_ if $count == 5;
		}
	}
	my $pos = -12;
	my $num = (split " ", $data[$pos])[0];
	my $start = $pos-$num+1;
	say $out $data[$start-2];
	for ($start..($pos+1)){
		say $out $data[$_];
	}
}
1;
