#!/usr/bin/perl
#get all the left snps(snps_left_1.raw, snps_left_2.raw, chr0/chr0.raw) in one file,
#and merge them, the output file is left_bin.raw

package new_perl::step4_merge_left;

use autodie;
use strict;
use warnings;
use new_perl::step3;

my $dir;
my $out;
my @files;
my @data_all;

sub new {
	my $class = shift;
	my $self  = bless { }, $class;
	return $self;
}

sub init {
	my $class = shift;

	$dir = shift;
	@files = qw(chr1 chr2 chr3 chr4 chr5 chr6 chr7 chr8 chr9 chr10);
	open $out, '>', $dir."left.raw";
	@data_all = ();
}

sub main {
	my $class = shift;

	for (0..9){
		open my $in_1, '<', $dir."$files[$_]/snps_left_1.raw";
		open my $in_2, '<', $dir."$files[$_]/snps_left_2.raw";
		
		push @data_all, $_ while <$in_1>;
		push @data_all, $_ while <$in_2>;
		#close $in_1, $in_2;
	}
	open my $in_3, '<', $dir."chr0/chr0.raw";
	<$in_3>;
	<$in_3>;
	push @data_all, $_ while <$in_3>;
	say $out "data type ri self";	#bs BBSSSSS
	my $num_of_mat = length ((split " ",$data_all[0])[1]);
	my $line_num = @data_all;
	say $out "$num_of_mat $line_num 0 symbols 1=A 2=B 0=- 3=-";
	map {print $out $_} @data_all;

	close $out;

	my $obj = new_perl::step3->new;
	$obj->init($dir, "left.raw", 1);
	$obj->doit();
}
1;
