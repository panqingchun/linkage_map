#/usr/bin/perl

use strict;
use warnings;
use autodie;

my $qunti = shift;
my $quntiName = shift;
#chdir "/media/文件/panqinchun/7_qunti/total_8_populations";

my @chr = qw(chr1  chr2 chr3 chr4 chr5 chr6 chr7 chr8 chr9 chr10 chr11 chr12 chr13 chr14 chr15 chr16 chr17 chr18 chr19 chr20);

open my $out, '>', "$qunti/map_all.csv";
open my $in, '<', "$qunti/chr1/step7/map.csv";
my $title = <$in>;
my @title = split ',', $title;
print $out "chr_num,".join ',', @title[2..$#title];
close $in;

my @data_chr;
my $count = 0;
for (@chr){
	$count++;
	open my $in, '<', "$qunti/$_/step7/map.csv";
	<$in>;
	my @data = <$in>;
	my $tmp=0;
	my $num = @data;
	push @data_chr, [$num];
	for my $line (@data){
		chomp $line;
		if (++$tmp == @data){
			print "...\n";
			my @lines = split ',', $line;
			$lines[5] = '--';
			say $out $count.",".join ',',@lines[2..$#title];
			last;
		}
		say $out "$count,".join ',',(split ',',$line)[2..$#title];
	}
	close $in;
}
close $out;


open $out, '>', "$qunti/map_all_all.csv";
open $in, '<', "$qunti/chr1/step7/map_hebin_all_A.csv";
$title = <$in>;
@title = split ',', $title;
print $out "chr_num,".join ',', @title[2..$#title];
close $in;

$count = 0;
for (@chr){
	$count++;
	open my $in, '<', "$qunti/$_/step7/map_hebin_all_A.csv";
	<$in>;
	my @data = <$in>;
	my $tmp=0;
	my $num = @data;
	$data_chr[$count-1][1] = $num;
	$data_chr[$count-1][2] = (split ',', $data[-1])[5];
	for my $line (@data){
		chomp $line;
		say $out "$count,".join ',',(split ',',$line)[2..$#title];
	}
	close $in;
}
close $out;

open $out, '>', "$qunti/tongji_chr.csv";
say $out "chr,num1,num2,length";
for (1..10){
	say $out "$chr[$_-1],".join ',', @{$data_chr[$_-1]};
}
close $out;	
