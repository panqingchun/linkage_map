#/usr/bin/perl

use strict;
use warnings;
use autodie;

my $qunti = shift;
my $quntiName = shift;
#chdir "/media/文件/panqinchun/7_qunti/total_8_populations";

my @chr = qw(chr1  chr2 chr3 chr4 chr5 chr6 chr7 chr8 chr9 chr10 chr11 chr12 chr13 chr14 chr15 chr16 chr17 chr18 chr19 chr20);
for (@chr){
	open my $in, '<', "$qunti/$_/step7/map_hebin.csv";
	open my $out, '>', "$qunti/$_/step7/map.csv";
	my $title = <$in>;
	my @data = <$in>;
	
	my $flag = 0;
	my @tmp_lines;
	print $out $title;
	for my $line(@data){
		chomp $line;
		my @lines = split ',', $line;
		if ($lines[5] != 0 && $flag == 0){
			say $out $line;
			next;
		}elsif ($lines[5] == 0 && $flag == 0){
			$flag = 1;
			@tmp_lines = @lines;
		}elsif($lines[5] == 0 && $flag == 1){
			@tmp_lines = @lines if $lines[4] < $tmp_lines[4];
		}elsif ($lines[5] != 0 && $flag == 1){
			$tmp_lines[5] = $lines[5];
			say $out join ',', @tmp_lines;
			$flag = 0;
		}
	}
	close $in;
	close $out;
}

		
