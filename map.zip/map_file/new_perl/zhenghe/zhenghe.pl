#/usr/bin/perl

use strict;
use warnings;
use autodie;

#chdir "/media/文件/panqinchun/7_qunti/total_8_populations";
my $qunti = shift;
my $quntiName = shift;


my @chr = qw(chr1  chr2 chr3 chr4 chr5 chr6 chr7 chr8 chr9 chr10 chr11 chr12 chr13 chr14 chr15 chr16 chr17 chr18 chr19 chr20);
my %info;
my %qunti_data;

open my $in, '<', "$qunti/chr_info.csv";
my $title = <$in>;
print $title;
while (<$in>){
	chomp $_;
	my @lines = split ',', $_;
	$info{$lines[1]} = "$lines[2],$lines[3]";
}

open my $in_qunti, '<', "$qunti/$quntiName.csv";
my $qunti_title = <$in_qunti>;
my @qunti_title = split ',', $qunti_title;
while (<$in_qunti>){
	chomp $_;
	my @lines = split ',', $_;
	$qunti_data{$lines[0]} = [(@lines[3..$#lines])];
}

my @data;
for(@chr){
	print "$_\n";
	@data = ();
	getData("$qunti/$_/",$_);
	merge("$qunti/$_/");
}

sub merge{
	my $dir = shift;
	open my $out, '>', $dir."/step7/map_hebin.csv";
	
	my $mat_name = join ',', @qunti_title[3..$#qunti_title];
	print $out "pos,id,name,chr,pos_m,pos_g,$mat_name";
	for (@data){
		#print $_;
		chomp;
		$_ =~ /\s*(\S*)\s*(\S*)\s*(\S*)/;
		my $pos = $1;
		my $id = $2;
		my $name = $3;
		#print $id."\n";
		$_ =~ /[^cM]*cM[^cM]*cM\s*(\S*)/;
		my $gene = join ',', @{$qunti_data{$name}};
		print $out "$pos,$id,$name,$info{$name},$1,$gene\n";
	}
	close $out;
}

sub getData{
	my $dir = shift;
	my $chr = shift;

	my $flag = 0;
	opendir my $dirname, "$dir/step7/";
	while (my $name = readdir $dirname){
		$flag = 1 if $name eq $chr."out";
	}
	if ($flag == 1){
		print "....\n";
		open my $in1, '<',"$dir/step7/".$chr."out"; 
		print "$dir/step7/".$chr."out\n";
		my @data_all = <$in1>;
		$data_all[-7] =~ /\s*(\S*)/;
		#print 
		my $num = $1;
		print $num."\n";
		my $j;
		for ($j = 20; $j<20+$num; $j++){
			push @data, $data_all[$j];
		}
		close $in1;
	}else{
		open my $in2, '<', "$dir/step7/"."map_finall.txt"; 
		my $title = <$in2>;
		@data = <$in2>;
		close $in2;
	}
}
