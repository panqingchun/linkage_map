#/usr/bin/perl

use strict;
use warnings;
use autodie;

#chdir "/media/文件/panqinchun/7_qunti/total_8_populations";
#chdir "/media/flying/disk";
my $qunti = shift;
my $quntiName = shift;

my @chr = qw(chr1  chr2 chr3 chr4 chr5 chr6 chr7 chr8 chr9 chr10 chr11 chr12 chr13 chr14 chr15 chr16 chr17 chr18 chr19 chr20);
my %info;
my %qunti_data;


open my $in, '<', "$qunti/chr_info.csv";
my $title = <$in>;
while (<$in>){
	chomp $_;
	my @lines = split ',', $_;
	$info{$lines[1]} = "$lines[2],$lines[3]";
}

open my $in_qunti, '<', "$qunti/$quntiName.csv";
my $qunti_title = <$in_qunti>;
my @qunti_title = split ',', $qunti_title;
while (<$in_qunti>){
	chomp $_;
	my @lines = split ',', $_;
	$qunti_data{$lines[0]} = [(@lines[3..$#lines])];
}

for my $chr (@chr){
	my %hebin;
	open my $in_hebin, '<', "$qunti/$chr/step3/bin_info.txt";
	while(<$in_hebin>){
		chomp;
		my @lines = split '\t';
		$hebin{$lines[0]} = [@lines];
	}
	
	open my $in_data, '<', "$qunti/$chr/step7/map_hebin.csv";
	my $title = <$in_data>;
	my @data;
	while(<$in_data>){
		chomp;
		push @data, [(split ',')];
	}

	open my $out, '>', "$qunti/$chr/step7/map_hebin_all.csv";
	print $out $title;
	my $gene_sum = 0;
	for(my $i = 0; $i<@data; $i++){
		my @data_out = ();
		if ($i == 0){$gene_sum = 0;}
		else{$gene_sum += $data[$i-1][5]; }
		#print ${$hebin{$data[$i][2]}}[0]."\n";
		for (@{$hebin{$data[$i][2]}}){
			my $gene = join ',', @{$qunti_data{$_}};
			my $chr_info = $info{$_};
			my $line = "$data[$i][0],$data[$i][1],$_,$chr_info,$gene_sum,$gene";
			my @lines = split ',', $line;
			push @data_out, [@lines];
		}
		@data_out = sort {$$a[4]<=>$$b[4]} @data_out;
		map {say $out join ',', @{$_}} @data_out;
	}

	close $in_hebin;#, $in_data, $out
	close $in_data;
	close $out;
}
