#!/usr/bin/perl

use strict;
#use warnings;
use autodie;

use File::Basename;


my $quntiFile =shift;
my $quntiName = shift;
my $chrInfoFile = shift;

my $mat_num = 0;
my $dir = dirname($quntiFile);
my $qunti = $quntiName;
open my $in1, '<', "$quntiFile";
my $title = <$in1>;
my @data1;
my @line;
while (<$in1>){
	last if $_ eq "";
	chomp;
	@line = split ",";
	#$line[0] = "*$line[0]";
	my $seq = join "",(@line[3..$#line]);
	push @data1, [($line[0],$seq)];
}
$mat_num = @line - 3;

open my $in2, '<', $chrInfoFile;
my %data2;
<$in2>;
while (<$in2>){
	last if $_ eq "";
	chomp;
	my @line = split ",";
	$data2{$line[1]} = [(substr($line[2],3),$line[3])];
}

my @data3;
for (@data1){
	#print ${$_}[1]."\n";
	my $chr_num = ${$data2{${$_}[0]}}[0];
	my $pos = ${$data2{${$_}[0]}}[1];
	push @{$data3[$chr_num]},[($pos,${$_}[0],${$_}[1])];
}

for (@data3){
	@{$_} = sort {${$a}[0] <=> ${$b}[0]} @{$_};
}

my $count = 0;
for (@data3){
	eval {unlink "$dir/chr".$count.".raw"};
	eval {mkdir "$dir/chr".$count};
	open my $out, '>', "$dir/chr".$count."/chr".$count++.".raw";
	my $title1 = "data type ri self";	#bs BBSSSSS
	my $line_num = @{$_};
	my $title2 = "$mat_num $line_num 0 symbols 1=A 2=B 0=- 3=-";
	say $out $title1;
	say $out $title2;
	for (@{$_}){
		say $out "*${$_}[1] ${$_}[2]";
	}
}
