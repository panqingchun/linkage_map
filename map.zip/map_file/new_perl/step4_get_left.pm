#!/usr/bin/perl
#get the snps which is not in the hebin.txt compared with the chr*_bin.raw,
#the output file is snps_left_2.raw.

package new_perl::step4_get_left;

use autodie;

my $dir;
my $fname;
my $out;
my @data_all;
my %hebin;

sub new {
	my $class = shift;
	my $self  = bless { }, $class;
	return $self;
}

sub init {
	my $class = shift;

	$dir = shift;
	$fname = shift;
	@data_all = ();
	%hebin = {};

	open $out, '>', $dir."snps_left_2.raw";
	open my $in1, '<', $dir."$fname";
	open my $in2, '<', $dir."step4/hebin.txt";
	<$in1>;
	<$in1>;
	push @data_all, $_ while <$in1>;
	$hebin{(split "\t")[0]} = 1 while <$in2>;
	close $in1;
	close $in2;
}
sub main {
	my $class = shift;

	map {print $out $data_all[$_-1] if !exists $hebin{$_}} 1..@data_all;
	close $out;
}
1;
