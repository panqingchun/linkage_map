#!/usr/bin/perl
#do a try for each snp in the left_bin.raw with the snps in the hebin.txt(trying to get them into the right position),
#the output file is try.map

package new_perl::step5;

use autodie;
use strict;
use warnings;
use new_perl::step4_use;

my ($dir,$fname);
my ($out, $in_bin, $in_hebin, $in_left);
my $num_hebin;

sub new {
	my $class = shift;
	my $self  = bless { }, $class;
	return $self;
}

sub init {
	my $class = shift;

	$dir = shift;
	$fname = shift;

	open $in_bin, '<', $dir.$fname."/".$fname."_bin.raw";
	open $in_hebin, '<', $dir.$fname."/step4/hebin.txt";
	open $in_left, '<', $dir."left_bin.raw";

	open $out, '>', $dir.$fname."/hebin_with_left.raw";

	$num_hebin = 0;
}

sub main{
	my $class = shift;

	get_hebin_with_left();
	close $out;
	close $in_bin;
	close $in_hebin;
	close $in_left;

	my $obj = new_perl::step4_use->new;
	$obj->init($dir.$fname."/hebin_with_left.raw",$dir.$fname."/try.map", $num_hebin+1);
	$obj->doit();
}

sub get_hebin_with_left {
	my (@data_bin, %data_hebin, @data_left);
	my @data_all;

	my $title1 = <$in_bin>;
	my $title2 = <$in_bin>;
	push @data_bin,$_ while <$in_bin>;

	$data_hebin{(split "\t",$_)[1]} = 1 while <$in_hebin>;

	$num_hebin = keys %data_hebin;

	<$in_left>;
	<$in_left>;
	push @data_left,$_ while <$in_left>;
	print "$#data_left..........\n";

	map {push @data_all, $_ if exists $data_hebin{substr( (split " ",$_)[0], 1 )."\n"}} @data_bin;
	map {push @data_all, $_} @data_left;

	print $out $title1;
	my @title2 = split " ", $title2;
	my $line_num = @data_all;
	$title2 = "$title2[0] $line_num 0 symbols 1=A 2=B 0=- 3=-";
	print $out $title2."\n";
	map {print $out $_} @data_all;

}
1;

