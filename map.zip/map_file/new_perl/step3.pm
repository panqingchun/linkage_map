#!/usr/bin/perl
#group the original chr*.raw and merge them, so we could reduce the number of the snps,
#the output file is chr*_bin.raw
 
package new_perl::step3;

use IPC::Open2;
use strict;
use warnings;
use autodie;

my $pid; 
my $dir;
my $fname;
my $fname1;
my $out;
my $out1;
my $out_bin;
my $out_left;
my @data_left;
my @data_count_2;

my $flag;#	if flag == 0, do group,else do mrkmerges

my @commands;
my @data;
my @idx_select;
my $select_in_2;


$SIG{INT} = \&final;
sub final {
	print "\nwait for exiting.........\n";
	print WRITE "exit\n";
	waitpid($pid,0);
	exit 0;
}

sub new {
	my $class = shift;
	my $self  = bless { }, $class;
	return $self;
}

sub init {
	my $class = shift;
	
	$dir = shift;
	$fname1 = shift;
	$flag = shift || 0;

	eval {mkdir $dir};
	eval {mkdir $dir."step3/"};
	#print $dir."step3/\n";
	$fname = $dir.$fname1;
	$pid = open2(*READ , *WRITE, 'carthagene 2>/dev/null');
	open $out, '>' ,$dir."step3/log.txt";
	#print $dir."step3/log.txt\n"
	$fname1 =~ /([^\.]*)\..*/;
	open $out1, '>' ,$dir."$1_bin.raw";
	open $out_left , '>', $dir."snps_left_1.raw" if $flag == 0;
	open $out_bin, '>', $dir."step3/bin_info.txt";
	@commands = (
	"dsload $fname",
	'group 0.1 8',
	'mrkselset [groupget 6]',
	'sem',
	'mrkmerges',
	'sem',
	'heaprintd',
	"exit",
	);
	@data = ();
	@idx_select = ();
	@data_left = ();
	@data_count_2 = ();
	$select_in_2 = 0;
}
sub doit {
	run_commands();
	get_the_first();
	get_snps_left() if $flag == 0;
	get_the_finall_data();
	close $out1;
	close $out;
	close $out_bin;
	close $out_left if $flag == 0;
}


sub run_commands {
	my $count = 0;
	
	for(0..$#commands){
		$count = 4 if $flag != 0 && $count == 1;
		last if $count == @commands;
		print WRITE $commands[$count++]."\n";
		print WRITE "\n";
		print $count." $commands[$count-1]\n";
		print $out "<$count>-------------------------------------------\n";
		while(<READ>){
			my $line = $_;	
			print $out $line;
			if ($count == 7){
				push @data, $line;
			
			}elsif($count == 2){
				chomp;
				push @data_count_2, $_;
			}		
			if ($line eq "CG> \n"){
				last;
			}
		}
		if ($count == 2){
			my @idx = ();
			for (1..$data_count_2[-2]){
				push @idx, [(length($data_count_2[$_ + 7]),$_)];
			}
			@idx = sort {$$a[0] <=> $$b[0]} @idx;
			$select_in_2 = 	$idx[-1][1];
			$commands[2] = "mrkselset [groupget $idx[-1][1]\]";
		}
	}
}


sub get_the_first {
	map {shift @data} 0..9;
	map {pop @data} 0..10;
	
	my @new_data;
	for (@data){
		chomp $_;
		$_ =~ /\s*([0-9]*)\s+([0-9]*)\s+([0-9a-zA-Z\-\.]*)\s+/;
		push @new_data, [($1,$2,$3)];
	}
	@new_data = sort {${$a}[0] <=> ${$b}[0] || ${$a}[1] <=> ${$b}[1] }@new_data;
	unshift @new_data, [qw(-1 -1 -1)];
	my $count = -1;
	my @data_bin_info;
	for (1..$#new_data){
		if ($new_data[$_][0] ne $new_data[$_-1][0]){
			push @idx_select, $new_data[$_][1] if $new_data[$_][0] ne $new_data[$_-1][0];
			push @data_bin_info, [($new_data[$_][2])];
			$count++;
		}else{
			push ${data_bin_info[$count]}, $new_data[$_][2]; #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		}
	}
	map {say $out_bin join "\t", @{$_}} @data_bin_info;
	@idx_select = sort {$a <=> $b} @idx_select;
	#print join "\n", @idx_select;
}

sub get_snps_left {
	my $line_num = $data_count_2[-2] - 1 + 8;
	for (8..$line_num){
		next if $_ == $select_in_2 + 7;
		my $line = $data_count_2[$_];
		chomp $line;
		$line =~ /[^:]*:(.*)/;
		push @data_left, split " ",$1;
	}
}	

sub get_the_finall_data {
	open my $in, '<', $fname;
	#print "$fname............\n";
	my @data_all;
	my $title1 = <$in>;
	my @title2 = split " ", <$in>;
	$title2[1] = @idx_select;
	while (<$in>){
		chomp;
		last if $_ eq "";
		push @data_all, $_;
	}
	print $out1 $title1;
	say $out1 join " ", @title2;
	map {print $out1 "$data_all[$_-1]\n" } @idx_select;

	map {print $out_left "$data_all[$_-1]\n" } @data_left if $flag == 0;
}

1;


