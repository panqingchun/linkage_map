#!/usr/bin/perl



my (@try1, @try2, @try3);
my $dir = "/home/maize/Desktop/BK_YU87-1-1_computer1/chr10/step4/";
open my $in1, '<', $dir."try1.map" or die;
open my $in2, '<', $dir."try2.map" or die;
open my $in3, '<', $dir."try3.map" or die;
<$in1>;
<$in2>;
<$in3>;
while(<$in1>){
	chomp;
	$_ =~ /\s*(\d*)\s*(\d*)\s*(\S*)\s*/ ;
	push @try1, [($2,$3)];
}
while(<$in2>){
	chomp;
	$_ =~ /\s*(\d*)\s*(\d*)\s*(\S*)\s*/ ;
	push @try2, [($2,$3)];
}
while(<$in3>){
	chomp;
	$_ =~ /\s*(\d*)\s*(\d*)\s*(\S*)\s*/ ;
	push @try3, [($2,$3)];
}
	map { $idx{${$_}[0]} = 1} @try1;
	doit_me(@try2);
	doit_me(@try3);

	#print the result
	open my $out, '>', $dir."hebin.txt" or die "cannot open :$!";
	print $dir."hebin.txt\n";
	map {print $out "${$_}[0]\t${$_}[1]\n"} @try1;

sub doit_me {
	my @try = @_;
	my @pos;
	for (@try){
		if (!exists $idx{${$_}[0]}){
			set_value($_);
		}
	}
}

sub set_value {
	my @value = @{$_[0]};
	my $flag = 0;
	for (0..$#try1){
		if ($value[0] < $try1[$_][0] ){
			if ($_ == 0){
				unshift @try1, [@value] ;
				$idx{$value[0]} = 1;
			}else{
			@try1 = (@try1[0..($_-1)],[@value],@try1[$_..$#try1]) if $_ >0;
			$flag = 1;
			$idx{$value[0]} = 1;			
			}
			last;
		}
	}

	if ($value[0] > $try1[-1][0] && $flag == 0){
		push @try1, [@value];
		$idx{$value[0]} = 1;
	}
}

