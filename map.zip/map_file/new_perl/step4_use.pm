#!/usr/bin/perl
#this module will do two things, 
#1> do a try in a random sequence for default;
#2> do a try for the sepecified snps in a continuous sequence, like 5,6,7..200, if the begin_num is not 0;
#the two ways will all return the map it generated.

package new_perl::step4_use;

use 5.010;
use IPC::Open2;
use strict;
use warnings;
use File::Basename;

our $VERSION = '0.01';

my $fname;
my $fmap;
my $out;
my $map_out;
my $pid;
my @commands;

my $begin_num;
my $flag_1 ;
my @try_out;

my @data;
my @idx_select;
my $num_of_snps = 0;
my $snps_left;	#the left snps after every time try;
my $snps_left2;
my @map;	#the final map data

sub new {
	my $class = shift;
	my $self  = bless { }, $class;
	return $self;
}

sub doit {
	my $class = shift;
	
	get_num_of_snps();
	run_commands();
	close $out;
	close $map_out;
	return @map;
}

$SIG{INT} = \&final;
sub final {
	print "\nwait for exiting.........\n";
	print WRITE "exit\n";
	waitpid($pid,0);
	exit 0;
}

sub init {
	my $class = shift;

	$fname = shift;
	$fmap = shift || "try.map";
	$begin_num = shift || 0;
	$flag_1 = 0;
	$flag_1 = 1 if $begin_num != 0;
	$pid = open2(*READ , *WRITE, 'carthagene 2>/dev/null');
	my $dir_log = dirname($fmap);
	my $name_log = basename($fmap);
	$name_log =~ /([^\.]*)\..*/;
	my $log_name = $1;
	open $out, '>' ,"$dir_log/$log_name.log";#/dev/null
	open $map_out, '>', $fmap or die "cannot open : $!";
	@commands = (
	"dsload $fname",
	'buildfw 3 3 { } 1',
	'mrkids',
	'mrkselset {}',
	'sem',
	'heaprintd',
	"exit",
	);
	@try_out = ();
	@map = ();
}

sub run_commands {	
	#initial
	$snps_left = join " ",(1..$num_of_snps);
	print WRITE $commands[0]."\n";	#load the data first
	my $sym = ".";
	my $ratio = 0;
	my $totle = $num_of_snps;
	printf "\r[ %.2f %s ]",$ratio,"%";
	select STDOUT;
	$| = 1;
	my $start = time;

	for($begin_num..$totle){
		if ($_ % 15 == 0){
			my $curr_time = time;
			my $time_used = $curr_time - $start;
			my $time_left = $time_used/($_-$begin_num + 1) * ($totle-$begin_num) - $time_used;
			$ratio = (($_-$begin_num)/($totle-$begin_num))*100;
			#$sym = $sym.".";
			printf "\r [ %.2f %s time used: $time_used s time left: %.2f s ]",$ratio,"%",$time_left;
		} 
		my $idx = $_;
		print $out "*********$_**************\n";

		if ($flag_1 == 0){
			set_command_1($snps_left);
		}else {
			set_command_1_2($snps_left, $_);
		}
		
		my $flag = run_command_1();
		if ($flag != 0 ){
			run_command_2();
			run_command_3();
		}else {
			$snps_left = $snps_left2;
			chomp $snps_left;
			$commands[3] = "mrkselset { $snps_left }";
			run_command_3();
			
		}
	}
	run_command_4_5();
	my $end = time;
	my $used = $end - $start;
	printf "\r  %.2f %s  time used:%.2fs                          ",100,"%",$used;
	print "\n";
	print WRITE $commands[6]."\n";
}

sub get_num_of_snps {
	open my $in, '<', $fname or die "cannot open $fname : $!";
	<$in>;
	$num_of_snps = (split " ", <$in>)[1];
}

sub set_command_1 {
	my @line = split " ",shift;
	my $select = rand(@line) % @line+1;
	my @seq ;
	map {push @seq, $line[$_-1] if $_ != $select} 1..@line;
	my $count = @seq;
	my $seq = join " ",@seq;
	$snps_left2 = $seq;
	$commands[1] = "buildfw 3 3 { $seq } 1";
}

sub set_command_1_2 {
	my @line = split " ",shift;
	my $curr = shift;
	my @seq;
	map {push @seq, $_ if $_ != $curr} @line;
	my $seq = join " ",@seq;
	$snps_left2 = $seq;
	$commands[1] = "buildfw 3 3 { $seq } 1";
}

sub run_command_1 {
	my @data_1;
	
	{
		print WRITE $commands[1]."\n";
		print WRITE "\n";
		#print "1 $commands[1]\n";
		print $out "<1>-------------------------------------------\n";	
		while(<READ>){
			my $line = $_;	
			print $out $line;
			push @data_1,$line;		
			if ($line eq "CG> \n"){
				last;
			}
		}
		my $tmp = grep {/:/} $data_1[-2];
		if (!$tmp){
			return 0;
		}else{
			my @line = split ":", $data_1[-2];
			$commands[2] = "mrkids $line[1]";
			return 1;
		}
	}
}

sub run_command_2 {
	{
		my @data = ();
		print WRITE $commands[2]."\n";
		print WRITE "\n";
		#print "2 $commands[2]\n";
		print $out "<2>-------------------------------------------\n";	
		while(<READ>){
			my $line = $_;	
			print $out $line;
			push @data, $line;
			if ($line eq "CG> \n"){
				last;
			}
		}
		$snps_left = $data[-2];
		$commands[3] = "mrkselset {$data[-2]}";
	}
}

sub run_command_3 {
	print $out "<3>-------------------------------------------\n";	
	print WRITE $commands[3]."\n";
	print WRITE "\n";
	my $tmp1 = <READ>;
	print $out $tmp1;
	#my $tmp2 = <READ>;
	while(<READ>){
		my $line = $_;	
		print $out $line;
		if ($line eq "CG> \n"){
			last;
		}
	}
}

sub run_command_4_5 {
	my @data_5 = ();
	for (4..5){
		my $idx = $_;
		print WRITE $commands[$idx]."\n";
		print WRITE "\n";
		while(<READ>){
			my $line = $_;	
			print $out $line;
			push @data_5, $line if $idx == 5;
			if ($line eq "CG> \n"){
				last;
			}
		}
		if ($idx == 5){
			my $pos = -12;
			my $num = (split " ", $data_5[$pos])[0];
			my $start = $pos - $num + 1;
			print $map_out $data_5[$start-2];
			for ($start..$pos){
				print $map_out $data_5[$_];
				$data_5[$_] =~ /\s*(\d*)\s*(\d*)\s*(\S*)\s*/ ;
				push @map, [($2,$3)];
			}
		}
	}
}

1;
