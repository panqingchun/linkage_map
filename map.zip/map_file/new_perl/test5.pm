#!/usr/bin/perl
#function:new()	init()	doit();
#args:init($dir,$fname1)
package new_perl::test5;



use strict;
use warnings;


my $str;

sub new {
	my $class = shift;
	my $self  = bless { }, $class;
	return $self;
}

sub do1 {
	my $class = shift;
	$str = "i can see you";
	do2();
}

sub do2 {
	print $str."\n";
}
sub END {
	print "i will always do...\n";
}
1;
