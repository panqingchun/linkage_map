#!/usr/bin/perl
#do a try for the snps in the chr*_bin.raw for three times to make sure they are on the right positions,
#and merge them in the hebin.txt
package new_perl::step4;

BEGIN{
push @INC, "H:";
push @INC, "/media/disk/";
}

use strict;
use warnings;
use IPC::Open2;

my $dir;
my $dir1;

my $fname;
my $obj;
my @try1;
my @try2;
my @try3;


my %idx;

sub new {
	my $class = shift;
	my $self  = bless { }, $class;
	return $self;
}

sub init {
	my $class = shift;

	$dir = shift;
	my $fname1 = shift;

	$fname = $dir.$fname1;
	$dir1 = $dir."step4/";
	mkdir $dir1;
	$obj = new_perl::step4_use->new;
	@try1 = ();
	@try2 = ();
	@try3 = ();
}

sub doit {
	$obj->init($fname,$dir1."try1.map");
	print "try1...\n";
	@try1 = $obj->doit();
	$obj->init($fname,$dir1."try2.map");
	print "try2...\n";
	@try2 = $obj->doit();
	$obj->init($fname,$dir1."try3.map");
	print "try3...\n";
	@try3 = $obj->doit();

	map { $idx{${$_}[0]} = 1} @try1;

	#merge
	doit_me(@try2);
	doit_me(@try3);

	#print the result
	open my $out, '>', $dir1."hebin.txt" or die "cannot open :$!";
	map {print $out "${$_}[0]\t${$_}[1]\n"}@try1;
}

sub doit_me {
	my @try = @_;
	my @pos;
	for (@try){
		if (!exists $idx{${$_}[0]}){
			set_value($_);
		}
	}
}

sub set_value {
	my @value = @{$_[0]};
	my $flag = 0;
	for (0..$#try1){
		if ($value[0] < $try1[$_][0] ){
			if ($_ == 0){
				unshift @try1, [@value] ;
				$idx{$value[0]} = 1;
			}else{
			@try1 = (@try1[0..($_-1)],[@value],@try1[$_..$#try1]) if $_ >0;
			$flag = 1;
			$idx{$value[0]} = 1;			
			}
			last;
		}
	}
	if ($value[0] > $try1[-1][0] && $flag == 0){
		push @try1, [@value];
		$idx{$value[0]} = 1;
	}
}
1;
