﻿#!/usr/bin/env perl

use 5.010;
use strict;
use warnings;

use File::Basename;

use new_perl::step1;
use new_perl::step2;
use new_perl::step3;
use new_perl::step4;
use new_perl::step4_get_left;
use new_perl::step4_merge_left;
use new_perl::step5;
use new_perl::step6;
use new_perl::step7;

my $quntiFile = shift @ARGV;
my $quntiName = shift @ARGV;
my $chrInfoFile = shift @ARGV;

my $dir = dirname($quntiFile);
$dir .= "/"; 

print $dir."\n";

=top
my $step1 = new_perl::step1->new;

	$step1->doit_1($quntiFile);
	$step1->doit_2($quntiFile);
	$step1->doit_3($quntiFile);
	my $new_dir = dirname($quntiFile);
	$step1->doit_4($new_dir."/step1/mat.csv", $new_dir."/step1/miss.csv", $new_dir."/step1/zahe.csv");


my $step2 ;


	$step2 = new_perl::step2->new;
	$new_dir = dirname($quntiFile);
	$step2->init($quntiFile);
	$step2->doit_1($new_dir."/step1/select.csv");
	$step2->doit_2();
	$step2->doit_3();
	$step2->doit_4();
	$step2->doit_5(0.01);	#0.01


#=cut

	print "...\n";
	system "perl new_perl/tiqu_chr.pl $dir/$quntiName.csv $quntiName $chrInfoFile";



my @files = qw(chr1 chr2 chr3 chr4 chr5 chr6 chr7 chr8 chr9 chr10 chr11 chr12 chr13 chr14 chr15 chr16 chr17 chr18 chr19 chr20);

print "-----------------step3-----------------\n";
my $step3 = new_perl::step3->new;
foreach (0..9){
	print "-----$_-----\n";
	$step3->init($dir."/$files[$_]/",$files[$_].".raw" );
	$step3->doit();
}


#my @files = qw(chr1 chr2 chr3 chr4 chr5 chr6 chr7 chr8 chr9 chr10 chr11 chr12 chr13 chr14 chr15 chr16 chr17 chr18 chr19 chr20);

print "-----------------step4-----------------\n";
foreach (0..9){
	my $step4 = new_perl::step4->new;
	print "-----$_------\n";
	$step4->init($dir."/$files[$_]/",$files[$_]."_bin.raw" );
	$step4->doit();
}


my $step4_left = new_perl::step4_get_left->new;
foreach (0..9){
	print "-----$_-----\n";
	$step4_left->init($dir."/$files[$_]/",$files[$_]."_bin.raw" );
	$step4_left->main();
}
=cut
#=top
my @files = qw(chr1 chr2 chr3 chr4 chr5 chr6 chr7 chr8 chr9 chr10 chr11 chr12 chr13 chr14 chr15 chr16 chr17 chr18 chr19 chr20);

my $step4_merge_left = new_perl::step4_merge_left->new;
$step4_merge_left->init($dir);
$step4_merge_left->main();
#=top
print "-----------------step5-----------------\n";
my $step5 = new_perl::step5->new;
foreach (0..9){
	print "-----$_-----\n";
	$step5->init($dir,$files[$_] );
	$step5->main();
}

print "-----------------step6-----------------\n";
my $step6 = new_perl::step6->new;
foreach (0..9){
	print "-----$_-----\n";
	$step6->init($dir,$files[$_] );
	$step6->main();
}
#=top
print "-----------------step7-----------------\n";
my $step7 = new_perl::step7->new;
foreach (0..9){
	print "-----$_-----\n";
	$step7->init($dir,$files[$_] );
	$step7->main();
}

