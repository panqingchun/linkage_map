#!/usr/bin/perl

use autodie;
use strict;
use warnings;

my $qunti = shift;
chdir "/media/文件/panqinchun/7_qunti/total_8_populations/$qunti";
eval {mkdir "work"};

my @chr = qw(chr1  chr2 chr3 chr4 chr5 chr6 chr7 chr8 chr9 chr10 chr11 chr12 chr13 chr14 chr15 chr16 chr17 chr18 chr19 chr20);
my $fmap;
my $fmap_all;

for (@chr){
	open my $in_map, '<', "$_/step7/map.csv";
	open my $in_map_all, '<', "$_/step7/map_hebin_all.csv";

	my $chr;
	$_ =~ /chr(.*)/;
	if (length($1) == 1){$chr = "ch0$1"}
	else{$chr = "ch$1"}
	open my $out_gene_all, '>', "work/$chr"."_gene_all";
	open my $out_gene_pos, '>', "work/$chr"."_gene_pos";
	open my $out_map, '>', "work/$chr"."_map";
	open my $out_set, '>', "work/$chr"."_set";
	open my $out_pos, '>', "work/$chr"."_pos";

	my $title_map = <$in_map>;
	chomp $title_map;
	my @title_map = split ',', $title_map;
	my @data_map;
	while (<$in_map>){
		chomp;
		push @data_map, [split ','];
	}

	my $title_map_all = <$in_map_all>;
	chomp $title_map_all;
	my @title_map_all = split ',', $title_map_all;
	my @data_map_all;
	while (<$in_map_all>){
		chomp;
		push @data_map_all, [split ','];
	}

	#ch01_gene_all
	say $out_gene_all join "\t", @title_map_all[0,6..$#title_map_all];
	map {say $out_gene_all join "\t", @{$_}[4,6..$#title_map_all]} @data_map_all;
	
	#ch01_gene_pos
	my $sum = 0;
	map {if ($_->[3] eq "chr$1"){say $out_gene_pos $_->[2]."\t$sum"; $sum += $_->[5];}} @data_map;

	#ch01_map
	$sum = 0;
	map {if ($_->[3] eq "chr$1"){say $out_map "$sum\t".join "\t", @{$_}[6..$#title_map_all]; $sum += $_->[5];}} @data_map;

	#ch01_pos
	map {say $out_pos "$_->[2]\t$_->[4]"} @data_map_all;

	#ch01_set
	map {say $out_set join "\t", @{$_}[5,4,2]} @data_map_all;

	#close ($in_map, $in_map_all);
	#close ($out_gene_all, $out_gene_pos, $out_map, $out_pos, $out_set);
}

