package new_perl::step2;

use 5.010;
use strict;
use warnings;

use File::Basename;

our $VERSION = '0.01';

sub new {
	my $class = shift;
	my $self  = bless { @_ }, $class;
	return $self;
}

my @data;
my @title;
my @new_data;
my @new_title;
my $out_name;
my %snp_select;
my $name_qun;
my @new1_data;
my $count = 0;

sub init {
	say ++$count;
	@data = ();
	@title = ();
	@new_data = ();
	@new_title = ();
	$out_name = "";
	@new1_data = ();
	%snp_select = ();

	my $self = shift;
	my $fname = shift;
	my $dir = dirname($fname);
	my $basename = basename($fname);
	say $basename;
	$basename =~ /([^.]*)\./;
	$name_qun = $1;
	$out_name = "$dir/$1_new.csv";


	mkdir "$dir/step2";
	open my $in , '<', $fname or die "cannot open $fname : $!";
	
	chomp (my $title = <$in>);
	@title = split ",", $title; 
	while (<$in>){
		chomp;
		push @data, [split ","];  
	}
	close $in;   
}    

sub doit_1 {
	my $self = shift;

	my $fname = shift;
	
	open my $in , '<', $fname or die "cannot open $fname : $!";
	open my $out , '>', $out_name or die "cannot open  : $!";
	
	my %mat_name;
	while (<$in>){
		chomp;
		if ((split ",")[0] eq "hebing"){  
			while (<$in>){
				chomp;
				$mat_name{(split ",")[1]} = 1;
			}
		}
	} ######
	for (my $i = 0; $i<@title; $i++){ 
		next if (exists $mat_name{$title[$i]}); 
		push @new_title, $title[$i];  
		for (my $j=0; $j<@data; $j++){ 
			push @{$new_data[$j]}, $data[$j][$i];    
		} 
	}
	#print
	say $out join ",", @new_title; 
	for (@new_data){
		say $out join ",", @{$_}; 
	}
	close $out;
	close $in; 
	return 1;
}


sub doit_2 {
	my $self = shift;
	
	my $dir = dirname($out_name);
	my $outf = $dir."/step2/parents.csv";
	open my $out , '>', $outf or die "cannot open file : $!";
	
	for (@new_data){
		my $p1 = ${$_}[1] ;
		my $p2 = ${$_}[2] ;
		if ($p1 eq "--" || $p2 eq "--" || substr($p1,0,1) ne substr($p1,1,1) || substr($p2,0,1) ne substr($p2,1,1)){
			say $out "${$_}[0],$p1,$p2"; 
			$snp_select{${$_}[0]} = 1; 
		}
	}
	close $out;
}
	
sub doit_3 {
	my $self = shift;
	
	my $dir = dirname($out_name);
	my $outf = $dir."/step2/static.csv";
	open my $out , '>', $outf or die "cannot open file : $!";
	#say $new_data[0][0];
	say $out "snp,missing,ratio,zahe,ratio"; 
	for (@new_data){  
		#say $new_data[0][0];
		my $count_miss = 0;
		my $count_zahe = 0;
		for (my $i=3; $i<@new_title; $i++){
			$count_miss++ if ${$_}[$i] eq "--";  
			$count_zahe++ if substr(${$_}[$i],0,1) ne substr(${$_}[$i],1,1); 
		}	
		my $ratio_miss = $count_miss/(@new_title-3);
		my $ratio_zahe = $count_zahe/(@new_title-3); 
		say $out "${$_}[0],$count_miss,$ratio_miss,$count_zahe,$ratio_zahe"; 
		$snp_select{${$_}[0]} = 1 if $ratio_miss > 0.15 || $ratio_zahe > 0.15; 
	}
	close $out;
}

sub doit_4 {
	my $self = shift;
	$name_qun =~ /^([^_]*)/; 
	my $oname1 = dirname($out_name)."/step2/".$1."_-1.csv";  
	my $oname2 = dirname($out_name)."/step2/".$1."_no_good.csv";
	
	open my $out1, '>', $oname1 or die "cannot open file : $!";
	open my $out2, '>', $oname2 or die "cannot open file : $!";


	say $out1 join ",", @new_title; 
	say $out2 join ",", @new_title; 
	for (@new_data){
		if (exists $snp_select{${$_}[0]}){ 
			say $out2 join ",", @{$_};
			
		}else{
			say $out1 join ",", @{$_};
			push @new1_data, $_;
		}
	}
	close $out1, $out2;
}    

sub doit_5 {
	my $self = shift;
	my $ratio = shift || 0.05;  ##### this is the maf of 5%
	$name_qun =~ /^([^_]*)/;
	my $oname1 = dirname($out_name)."/".$1.".csv";
	my $oname2 = dirname($out_name)."/step2/".$1."_ratio.csv";
	
	open my $out1, '>', $oname1 or die "cannot open file : $!";
	open my $out2, '>', $oname2 or die "cannot open file : $!";

	say $out1 join ",", @new_title;
	
	for (@new1_data){
		my $count1 = 0;
		my $count2 = 0;
		if (${$_}[1] ne ${$_}[2]){
			for (my $i=3; $i<@new_title; $i++){
				$count1++ if ${$_}[$i] eq ${$_}[1];
				$count2++ if ${$_}[$i] eq ${$_}[2];
			}
			my $max = $count1>$count2 ? $count1:$count2;
			my $min = $count1<=$count2 ? $count1:$count2;
			my $ratio1 = $min/$max;
			if ( $ratio1 < $ratio){
				say $out2 "${$_}[0],$ratio1";
			}else{
				my @line = zhuanhuan($_);
				say $out1 join ",", @line;
			}	
		}
	}
	close $out1, $out2;
}

sub zhuanhuan { 
	my @line = @{ shift @_};	
	for (my $i=3; $i<@new_title; $i++){
		if ($line[$i] eq $line[1]){
			$line[$i] = 1;
		}elsif ($line[$i] eq $line[2]){
			$line[$i] = 2 ;
		}elsif ($line[$i] eq "--"){
			$line[$i] = 0;
		}else {
			$line[$i] = 3;
		}
	}
	$line[1] = 1;
	$line[2] = 2;
	return @line;
}

1;
