#!/usr/bin/perl
#use strict
#填补缺失的SNP
#need one file
#the formate of the data :
# line:the SNPs ,column:the matierial science and the first line is the gene distance(pluse)

mkdir "result_map_no3/";

my $fname=shift @ARGV;
open(FI,"<",$fname) or die;
#$fname = substr $fname,0,4;
unlink("result_map_no3/".$fname."_map_no3_result");
open FO,'>>',"result_map_no3/".$fname."_map_no3_result"  or die;
$geneDist=<FI>;
chomp($geneDist);
@geneDist=split(/\t/,$geneDist);
@gene=<FI>;

map {print FO $_."\t"} @geneDist;
print FO ("\n");
#change 3 to 0
foreach(0..$#gene){
	chomp($gene[$_]);
	@line0=split /\t/,$gene[$_];
	map {if ($line0[$_] == 3){$line0[$_]=0;}} 0..$#line0;
	$gene[$_]=join "\t" , @line0;
}

$count=0;
foreach $N (0..$#gene){
	$count++;
	chomp($gene[$N]);
	@genel=split(/\t/,$gene[$N]);
	#$mat_name = shift @genel;
	$pos1=-2;
	$pos2=-2;
	foreach(0..$#genel){
		if ($genel[$_]==0 && $pos1==-2){
			$pos1=$_-1;
		}
		elsif ($genel[$_]!=0 && $pos1!=-2){
			$pos2=$_;
			if($pos1!=-1){
				$averag=($geneDist[$pos1]+$geneDist[$pos2])/2;
			}
		}
		if ($_==0 && $genel[$_]==0){
			$averag=-100000;
			$pos1=-1;
		}
		elsif ($_==$#genel && $genel[$_]==0){
			$averag=1000000;
			$pos2=$#genel+1;
		}
		if ($pos2!=-2 && $pos1!=-2){
			foreach(($pos1+1)..($pos2-1)){
				if ($geneDist[$_]<$averag){$genel[$_]=$genel[$pos1];}
				else {$genel[$_]=$genel[$pos2];}
			}
			$pos1=-2;
			$pos2=-2;
		}
	}
	$genel[0] = $genel[1] if $genel[0] == 0;
	#unshift @genel,$mat_name;
	#print $mat_name."\n";
	$gene[$N]=join "\t",@genel;
}
map {print FO ($_."\n")} @gene;
