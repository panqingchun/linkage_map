#!/usr/bin/perl 
#按照窗口的大小来计算覆盖度

my $fi = shift @ARGV;
my $win_size = shift @ARGV;
my $fo = $fi."_cov";

open my $in, '<' ,$fi or die;
open my $out , '>' , $fo or die;

if ($win_size == 0){
	$win_size = 1000000;
} 
my $win_curr = $win_size;
my $win_count = 0;
my $chr_curr = 1;
my @data;
while (<$in>){
	chomp;
	push @data , [split /\t/];
}

print $out ("chr\twindow size(M)\tcount\n");
foreach (@data){
	if ($chr_curr == ${$_}[1]){
		if (${$_}[3]<$win_curr || (${$_}[2]+${$_}[3])/2 <= $win_curr){
			$win_count++;
		}else {
			print $out (${$_}[1]."\t".($win_curr/1000000)."\t".$win_count."\n");
			$win_curr +=$win_size;
			$win_count = 0;
		}
	}else{
		$chr_curr = ${$_}[1];
		$win_curr = $win_size;
		$win_count = 0;
	
	}
}
		
