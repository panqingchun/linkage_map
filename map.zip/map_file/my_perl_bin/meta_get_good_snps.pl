#!/usr/bin/perl

my $dir = shift ; #"/media/disk/my_perl_bin/";
@num = map { sprintf "%02d",$_} 1..10;
eval {unlink "good_snps/left_data"};
map {system "perl $dir/get_good_snps.pl result_distance/set_name_all/ch".$_."_name_all  ch".$_."_gene_pos";} @num;
