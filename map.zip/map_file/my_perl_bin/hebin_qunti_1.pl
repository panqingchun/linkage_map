#/usr/bin/perl

use strict;
use warnings;
use autodie;


chdir "/media/文件/panqinchun/7_qunti/total_8_populations";
my $dir = "hebin_qunti/";
eval {mkdir $dir};
my @chr = qw(ch01  ch02 ch03 ch04 ch05 ch06 ch07 ch08 ch09 ch10);
my @qunti = qw(BB BK KC KD KUI3 MO17 SK ZONG3); #KUI3 MO17 SK ZONG3
my $qunti_num = @qunti;
my %mat_name = ();
my @gene_data = ();
my %snp_name = ();

my @title_t;

hebin_help();
for (@chr){
	hebin($_);
}


sub hebin_help {
	for (@qunti){
		open my $in, '<', "$_/$_"."_final_mat.csv";
		my $title = <$in>;
		chomp $title;
		my @title = split ',', $title;
		for (3..$#title){push @title_t, $title[$_];}
		my @data;
		while (<$in>){
			chomp;
			my @lines = split ',',$_;
			push @data, \@lines;
		}
		print $data[0][0]."\n";
		@data = sort {$a->[1] <=> $b->[1]} @data;
		push @gene_data, [@data];
	}
}

sub hebin {
	my $chr = shift;
	open my $out, '>', "$dir/$chr.csv";
	#输出标题
	say $out "name,chr,pos,".join ',',@title_t;
	#
	my $num = @{$gene_data[0]}-1;
	print $num."\n";
	for my $idx (1..$num){
		next if  $gene_data[0][$idx][0] ne $chr;
		print $out $gene_data[0][$idx][2].",$gene_data[0][$idx][0],$gene_data[0][$idx][1],";
		for my $qunti_data (@gene_data){
			my $idx = @{$qunti_data->[$idx]}-1;
			print $out join ',',@{$qunti_data->[$idx]}[3..$idx];
		}
		print $out "\n";
	}
	close $out;
}
