#!/usr/bin/perl
#compute the coverage
#need one input file:the first column is the position,and the others are the gene type

my $fname=shift @ARGV;
unlink $fname.".cov";
open my $fh,'<',$fname;
open my $out,'>>',$fname.".cov" or die;
my @pos_flag;
while(<$fh>){
	chomp;
	if ($_ eq ""){next;}
	my $flag=0;
	my @tmp=split /\t/;
	foreach (@tmp){
		if ($_ == 3){
			$flag=1;
			push @pos_flag,[@tmp[0],3];
			last;
		}
	}
	if ($flag == 0){
		push @pos_flag,[@tmp[0],0];
	}
}

unshift @pos_flag,[$pos_flag[0][0],0];
push @pos_flag,[$pos_flag[$#pos_flag][0],0];
my $pos=0;
foreach my $i (1..$#pos_flag){
	if ($pos_flag[$i][1] == 3){
		$pos = $pos+($pos_flag[$i][0]+$pos_flag[$i+1][0])/2-($pos_flag[$i][0]+$pos_flag[$i-1][0])/2;
	}
}
my $coverage=$pos/($pos_flag[$#pos_flag][0]-$pos_flag[1][0]);
print $out ("coverage:\t".$coverage."\n");
