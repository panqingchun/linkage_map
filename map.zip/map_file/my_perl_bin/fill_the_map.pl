#!/usr/bin/perl
#use strict
#填补缺失的SNP
#need one file
#the formate of the data :
# line:the SNPs ,column:the matierial science and the first line is the gene distance(pluse)

mkdir "result_map/";

my $fname=shift @ARGV;
open(FI,"<",$fname) or die;
#$fname = substr $fname,0,4;
unlink("result_map/".$fname."_map_result");
open FO,'>>',"result_map/".$fname."_map_result"  or die;
$geneDist=<FI>;
chomp($geneDist);
@geneDist=split(/\t/,$geneDist);
my $t_flag = 1 if !($geneDist[0] =~ /\d/);
shift @geneDist if $t_flag == 1;
@gene=<FI>;

map {print FO $_."\t"} @geneDist;
print FO ("\n");

$count=0;
foreach $N (0..$#gene){
	$count++;
	chomp($gene[$N]);
	@genel=split(/\t/,$gene[$N]);
	$mat_name = shift @genel if $t_flag == 1;
	$pos1=-2;
	$pos2=-2;
	foreach(0..$#genel){
		if ($genel[$_]==0 && $pos1==-2){
			$pos1=$_-1;
		}
		elsif ($genel[$_]!=0 && $pos1!=-2){
			$pos2=$_;
			if($pos1!=-1){
				$averag=($geneDist[$pos1]+$geneDist[$pos2])/2;
			}
		}
		if ($_==0 && $genel[$_]==0){
			$averag=-100000;
			$pos1=-1;
		}
		elsif ($_==$#genel && $genel[$_]==0){
			$averag=1000000;
			$pos2=$#genel+1;
		}
		if ($pos2!=-2 && $pos1!=-2){
			foreach(($pos1+1)..($pos2-1)){
				if ($geneDist[$_]<$averag){$genel[$_]=$genel[$pos1];}
				else {$genel[$_]=$genel[$pos2];}
			}
			$pos1=-2;
			$pos2=-2;
		}
	}
	$genel[0] = $genel[1] if $genel[0] == 0;
	#unshift @genel,$mat_name;
	#print $mat_name."\n";
	$gene[$N]=join "\t",@genel;
}
map {print FO ($_."\n")} @gene;
sub sorted{
	@line=split(/\t/, $_[0]);
	$back=100000;
	foreach $I (1..$#line){
		if($line[$I]==3){
			$back=$I;
			last;
		}
	}
	$back;
}
my @sort_id;
foreach(0..$#gene){
	$sort_id[$_]=sorted($gene[$_]);
}

foreach(0..@sort_id){
	$gene_with_id[$_]=([$sort_id[$_],$gene[$_]]);
}
@sorted_gene=sort {$b->[0] <=> $a->[0]}  @gene_with_id;
#map {print FO ($_->[1]."\n")} @sorted_gene;

