#!/usr/bin/perl

my $qunti = shift;
my $dir = "/media/文件/panqinchun/7_qunti/total_8_populations/fu/my_perl_bin/";
my $dir0 = "/media/文件/panqinchun/7_qunti/total_8_populations/$qunti/work/";
chdir $dir0;
exec "perl $dir/meta.pl $qunti $dir";
#exec "perl $dir/meta_get_good_snps.pl ";
