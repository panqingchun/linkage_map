#!/usr/bin/perl

my $dir = shift; #"/media/disk/my_perl_bin/";
@num = map { sprintf "%02d",$_} 1..10;

#map {system "perl $dir/cov_by_window_data.pl result_distance/set_name_sort_by_phy/ch".$_."_name_all  ch".$_."_gene_pos";} @num;
map {system "perl $dir/draw_map_data_all_new.pl result_distance/set_name_all/ch".$_."_name_all  ch".$_."_gene_pos";} @num;
#map {system "perl $dir/draw_map.pl cov_by_window_data/ch".$_."_draw_map_data_phy_all cov_by_window_data/ch".$_."_draw_map_data_gene_all";} @num;
map {system "perl $dir/draw_map.pl draw_map_data/ch".$_."_draw_map_data_phy_all draw_map_data/ch".$_."_draw_map_data_gene_all";} @num;

#map {system "perl $dir/ratio_of_gene_and_phy.pl result_distance/set_name_all/ch".$_."_name_all  ch".$_."_gene_pos";} @num;
