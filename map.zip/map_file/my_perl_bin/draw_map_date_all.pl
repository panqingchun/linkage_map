#!/usr/bin/perl
#compute the data for drawing the map
#need two files:
#1.the set name which is sorted by physical distance,such as 1 name1 \n 1 name2 \n 2name3.....
#2.the first name of the set which is sorted by the genatic distance.

mkdir "draw_map_data/";
$fname1 = shift @ARGV;
$fname2 = shift @ARGV;
print $fname1."\n";
open my $fh1,'<',$fname1 or die;
open my $fh2,'<',$fname2 or die;
$fname1 =~ /([^\/]*)$/;
$fname1 = $1;
$fname1 = substr $fname1,0,4;
$out1="draw_map_data/".$fname1."_draw_map_data_phy_all";
$out2="draw_map_data/".$fname1."_draw_map_data_gene_all";
unlink $out1;
unlink $out2;

open my ($out_phy) ,'>>',$out1 or die;
open my ($out_gene) ,'>>',$out2 or die;

while(<$fh1>){
	chomp;
	push @phy,[split /\t/];
}
while(<$fh2>){
	chomp;
	push @gene,[split /\t/];
}

my @phy1;
my $set = $phy[0][2];
my @tmp1,%name;
my $count = 1;
for (my $i=0;$i<@phy;$i++){
	if ($phy[$i][2] == $set){
		push @tmp1, [($phy[$i][0],$phy[$i][1],0)];
		$name{$phy[$i][0]} = $count;
		#print $phy[$i][0]."\n";
	}else{
		push @phy1, [@tmp1];
		@tmp1 = undef;
		shift @tmp1;
		$set = $phy[$i][2];
		$count++;
		$i--;
	}
}

for (my $i = 1 ; $i <@phy1 ; $i++){
	for (my $j = 0 ; $j<@{$phy1[$i]} ; $j++){
		if ($phy1[$i][$j][1] < $phy1[$i-1][-1][1]){
			$phy1[$i-1][-1][2] = 1;
			$phy1[$i][$j][2] = 1;
		}
	}
}

#print the result
for (my $i = 0 ; $i < @phy1 ; $i++){
	print $out_phy ("$phy1[$i][0][0]\t$phy1[$i][0][1]\n");
	for (my $j = 1 ; $j<@{$phy1[$i]} ; $j++){
		if ($phy1[$i][$j][2] == 1 ){
			if ($j != $#{$phy1[$i]} && $name{$phy1[$i][$j][0]} != $name{$phy1[$i][0][0]} ){
				print $out_phy ("$phy1[$i][$j][0]\t$phy1[$i][$j][1]\n");
			}elsif($j == $#{$phy1[$i]}){
				print $out_phy ("$phy1[$i][$j][0]\t$phy1[$i][$j][1]\n");
			}
		}
	}
}

map { $temp{$phy1[$_][0][0]} = $phy1[$_];} 0..$#phy1;

for (my $i = 0 ; $i < $#gene ;$i++){
	print $out_gene ("$gene[$i][0]\t$gene[$i][1]\n");
	my $name = $gene[$i][0];
	for (my $j = 1 ; $j < @{$temp{$name}} ; $j++){
		if (${$temp{$name}}[$j][2] == 1){
			if ($j != $#{$temp{$name}}  && $name{${$temp{$name}}[$j][0]} != $name{${$temp{$name}}[0][0]} ){
				print $out_gene ("${$temp{$name}}[$j][0]\t$gene[$i][1]\n");
			}elsif($j == $#{$temp{$name}}){
				print $out_gene ("${$temp{$name}}[$j][0]\t$gene[$i][1]\n");
			}
		}
	}
}







