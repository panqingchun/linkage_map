#!/usr/bin/perl

my $qunti = shift;
my $dir = shift ;


system "perl $dir/meta_function.pl $dir";
print "done.....................\n";
system "perl $dir/meta_com_the_covr.pl $dir";
print "done.....................\n";
system "perl $dir/meta_draw_map.pl $dir";
print "done.....................\n";
system "perl $dir/meta_ratio.pl $dir";
print "done.....................\n";
system "perl $dir/meta_get_good_snps.pl  $dir";
print "done.....................\n";
