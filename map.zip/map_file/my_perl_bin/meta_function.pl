#!/usr/bin/perl

my $dir = shift; #"/media/disk/my_perl_bin/";

@num = map { sprintf "%02d",$_} 1..10;
map {system "perl $dir/compute_the_distance.pl ch".$_.'_set ch'.$_.'_pos ch'.$_.'_gene_pos';} @num;
map {system "perl $dir/Transpose.pl ch".$_.'_map'}@num;
map {system "perl $dir/fill_the_map.pl ch".$_.'_map.tr'} @num;
map {system "perl $dir/fill_the_map_no_3.pl ch".$_.'_map.tr'} @num;
map {unlink "perl $dir/ch".$_.'_map.tr'} @num;


