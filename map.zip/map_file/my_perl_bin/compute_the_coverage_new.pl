#!/usr/bin/perl
#need one file:each line of the file is a material

mkdir "coverage";

my $fname = shift @ARGV;

open my $fin,'<',$fname or die;
$fname =~ /([^\/]*)$/;
$fname = $1;
$fname = substr $fname,0,4;

open my $out,'>',"coverage/".$fname."_cov" or die;

print $out ("material\tch\tstart\tend\tlength\n");

my $line = <$fin>;
chomp $line;
my @pos = split /\t/,$line;
shift @pos;
unshift @pos,-$pos[0];
push @pos,$pos[-1];

my @new_line;
my $flag1,$flag2;
my $pos1,$pos2;
my $count=0;

while (<$fin>){
	my $fragment=0;
	$count++;
	chomp;
	if ($_ eq "") {next;}
	my @line = split /\t/;
	$mat_name = shift @line;
	#print 
	#unshift @line,0;
	#push @line,0;
	my @stack;
	foreach (0..$#line){
		if ($line[$_] == 3){ push @stack,$_ ; }
	}
	my $pos1=$stack[0]+1;
	my $pos2=0;
	$new_line[$stack[0]] = 3;
	foreach (1..$#stack){
		if ($stack[$_] - $stack[$_-1] < 3){
			foreach ($stack[$_-1]..$stack[$_]){$new_line[$_] = 3;}
			next;
		}else {
			$pos2 = $stack[$_-1]+1;
			if ($pos1 != $pos2){
				my $_pos1 = ($pos[$pos1-1] + $pos[$pos1])/2;
				my $_pos2 = ($pos[$pos2+1] + $pos[$pos2])/2;
				print $out ("$mat_name\t$fname\t$_pos1\t$_pos2\t".($_pos2-$_pos1)."\n");
				$pos1 = $stack[$_]+1;
				$pos2 = 0;
				$fragment++;
			}
		}
	}
}


my $len = 0;
push @new_line,0;
unshift @new_line,0;

foreach (1..$#new_line-1){
	if ($new_line[$_] == 3){
		$end = ($pos[$_]+$pos[$_+1])/2;
		$start = ($pos[$_]+$pos[$_-1])/2 ;
		$len += $end - $start ;
		#print "$start\t$end\t$len\n";
	}
}
my $coverage = $len / $pos[-1];
print $out ("coverage:\t$coverage");

close $fin;
close $out;
