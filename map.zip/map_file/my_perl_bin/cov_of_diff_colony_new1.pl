#!/usr/bin/perl
#args:the index of the chr , the file of the chrs' length , the files.

mkdir "cov_diff_colony/";

my @data;

#my $fileNum = shift @ARGV;
my $n = shift @ARGV;
my $AllLength = shift @ARGV;

while(@ARGV>0){
	my $colony = shift @ARGV;
	open $fi , '<' , $colony or die;
	while(<$fi>){
		chomp;
		my @tmp = split /\t/;
		push @data , \@tmp;
	}
	close $fi;
}

open $fiL , '<' , $AllLength or die;

open my $out , '>' , "cov_diff_colony/coverage_all_colonies$n.txt" or die;

@LL = <$fiL>;
$Length = $LL[$n-1]*1000000;

my @data1;
my @data2;
for ($i = 0 ; $i <= $#data ; $i+=2){
	if ($data[$i][2] != $data[$i+1][2]){
		push @data1 , [$data[$i][1] , $data[$i+1][1] , $data[$i][2] , $data[$i+1][2]];
		push @data2 , [$data[$i][1] , $data[$i][2]];
		push @data2 , [$data[$i+1][1] , $data[$i+1][2]];
	}
}
@data1 = sort{${$a}[2]<=>${$b}[2]} @data1;
@data2 = sort{${$a}[1]<=>${$b}[1]} @data2;

for (my $i=0 ; $i<$#data2 ;$i++){
	$pos1 = $data2[$i][1];
	$pos2 = $data2[$i+1][1];
	if ($pos1 == $pos2){
		next;
	}
	foreach my $d(@data1){
		if ($pos1>=${$d}[2] && $pos2<=${$d}[3]){
			print $out ($data2[$i][0]."\t".$data2[$i+1][0]."\t".$pos1."\t".$pos2."\n");
			$L+=($pos2-$pos1);
			last;
		}
	}
}
print $L."\n".$Length;
my $cov = $L/$Length;
print $out ("coverage: ".$cov);