#!/usr/bin/perl

#$_="01";
my $dir = shift ; #"/media/disk/my_perl_bin/";
@num = map { sprintf "%02d",$_} 1..10;
foreach(@num){
	system "perl $dir/Transpose.pl ch".$_."_gene_all";
	system "perl $dir/fill_the_map.pl ch".$_."_gene_all.tr";
	system "perl $dir/compute_the_coverage_new.pl result_map/ch".$_."_gene_all.tr_map_result";
	system "perl $dir/compute_the_coverage_merge_by_dis.pl result_map/ch".$_."_gene_all.tr_map_result";
	system "perl $dir/coverage_of_material.pl result_map/ch".$_."_gene_all.tr_map_result";
	unlink "ch".$_."_gene_all.tr", "result_map/ch".$_."_gene_all.tr_map_result";
	print $_."\n";
}
#system "rm -rf result_map";
