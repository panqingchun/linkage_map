#!/usr/bin/perl
#compute the data for drawing the map
#need two files:
#1.the set name which is sorted by physical distance,such as 1 name1 \n 1 name2 \n 2name3.....
#2.the first name of the set which is sorted by the genatic distance.

mkdir "draw_map_data/";
$fname1 = shift @ARGV;
$fname2 = shift @ARGV;

open my $fh1,'<',$fname1 or die;
open my $fh2,'<',$fname2 or die;
$fname1 =~ /([^\/]*)$/;
$fname1 = $1;
$fname1 = substr $fname1,0,4;
$out1="draw_map_data/".$fname1."_draw_map_data_phy";
$out2="draw_map_data/".$fname1."_draw_map_data_gene";
unlink $out1;
unlink $out2;

open my ($out_phy) ,'>>',$out1 or die;
open my ($out_gene) ,'>>',$out2 or die;

while(<$fh1>){
	chomp;
	push @phy,[split /\t/];
}
while(<$fh2>){
	chomp;
	push @gene,[split /\t/];
}

for (my $i=0;$i<@phy-2;$i+=2){
	if ($phy[$i+2][2]<$phy[$i+1][2]){$phy[$i][3] = 1;}
	else {$phy[$i][3] = 0;}
}
$phy[$#phy-1][3] = 0;

#print the result
for ($i=0;$i<@phy;$i+=2){
	if ($phy[$i][3] == 1){print $out_phy ("$phy[$i][1]\t$phy[$i][2]\n$phy[$i+1][1]\t$phy[$i+1][2]\n");}
	else {print $out_phy ("$phy[$i][1]\t$phy[$i][2]\n");}
}
map { $temp{$phy[$_][1]} = "$phy[$_][3]\t$phy[$_+1][1]";} 0..$#phy;
foreach (0..$#gene){
	($flag,$name)=split /\t/,$temp{$gene[$_][0]};
	if ($flag == 1){print $out_gene "$gene[$_][0]\t$gene[$_][1]\n$name\t$gene[$_][1]\n";}
	else {print $out_gene ("$gene[$_][0]\t$gene[$_][1]\n")}
}
