#!/usr/bin/perl
#获取属于同一个并中的材料名称（分别为第一个和最后一个）。
#need three files and there are two output files ;
#input files:1.the SNPs with set information in thre lines(set,idx,name);
#               2.the SNPs with position(physics) information in two lines(name,pos);
#               3.each sets' first SNPs and it is sorted by the Genetic distance in one lines;
#output files:1.the distance of each set;
#                 2.the distance between the adjacent set;
#				3.the first and the last name of each set whitch is sorted by the genatic distance;
#				4.the first and the last name of each set whitch is sorted by the physicle distance;


use File::Path;

mkpath "result_distance/inner_distance";
mkpath "result_distance/outer_distance";
mkpath "result_distance/set_name";
mkpath "result_distance/set_name_sort_by_phy";
mkpath "result_distance/set_name_all";
my $fname1=shift @ARGV;
my $fname2=shift @ARGV;
my $fname3=shift @ARGV;

open my ($data1) ,'<', "$fname1" or die "cannot open $fname1 $!";
open my ($data2) ,'<', "$fname2" or die;
open my ($data3) ,'<', "$fname3" or die;

$fname1 = substr $fname1,0,4;
unlink("result_distance/inner_distance/".$fname1."_inner_distance_result");
unlink("result_distance/outer_distance/".$fname1."_outer_distance_result");
unlink("result_distance/set_name/".$fname1."_set_name_result");
unlink("result_distance/set_name_sort_by_phy/".$fname1."_set_name_sort_by_phy_result");
unlink("result_distance/set_name_all/".$fname1."_name_all");

open my ($out),'>>', "result_distance/inner_distance/".$fname1."_inner_distance_result" or die;
open my ($out_space),'>>', "result_distance/outer_distance/".$fname1."_outer_distance_result" or die;
open my ($out_set),'>>', "result_distance/set_name/".$fname1."_set_name_result" or die;
open my ($out_set_phy),'>>', "result_distance/set_name_sort_by_phy/".$fname1."_set_name_sort_by_phy_result" or die;
open my ($out_all),'>>',"result_distance/set_name_all/".$fname1."_name_all" or die;

@data1=<$data1>;
@data2=<$data2>;
@name_set = map {chomp;(split /\t/,$_)[2];} @data1;
map {chomp} @data2;
@pos=map {[split /\t/]} @data2;
%pos=map {split /\t/} @data2;
@selected_name=<$data3>;
map {chomp} @selected_name;
%gene_dis = map {(split /\t/,$_)} @selected_name;
@selected_name = map {(split /\t/,$_)[0]} @selected_name;

#print keys %pos;
#提取首尾基因名称
push @data1,$data1[-1];
my $tmp1=-1;
my $name1;
my $tmp2=-1;
my $name2;
my %name;
my $count=0;
my $idx;
my $bin=1;
foreach my $n (0..$#data1){
	chomp($data1[$n]);
	my @line=split(/\t/,$data1[$n]);
	if($n==$#data1){$tmp1=0;};
	if ($tmp1==-1){$tmp1=$line[0];$name1=$line[2];$idx=$n;}
	elsif ($tmp1!=-1 && $line[0]!=$tmp1){
		$tmp2=$line[0];
		$name2=$last_line[2];
		#print $name1;
		foreach(0..$#pos){
			if ($name1 eq $pos[$_][0]) {
				$name{"$name1\t$name2"}=$_;
				last;
			}
		}
		$tmp1=$tmp2;
		$tmp2=-1;
		$name1=$line[2];
		$idx=$n;
	}
	@last_line=@line;
}

@new_name=sort {$name{$a}<=>$name{$b}} keys %name;

#map {print $_."\n" } @selected_name;
#compute the inner distense for each club;
@sorted_name=map {[split /\t/]} @new_name;
foreach my $i (0..$#sorted_name){
	foreach(@selected_name){
		if ($sorted_name[$i][0] ~~ $_){
			push @sorted_name_new, $sorted_name[$i];
			last;
		}
	}
}

@sorted_name=@sorted_name_new;
#print the set
my $count_me=1;
foreach(0..$#sorted_name){
	if($sorted_name[$_][0] eq $sorted_name[$_][1]){print $out_set ($count_me++."\t$sorted_name[$_][0]\n")}
	else {print $out_set ("$count_me\t$sorted_name[$_][0]\n".$count_me++."\t$sorted_name[$_][1]\n")}
}


my $curr_pos;
my $count=0;
foreach $i (0..$#sorted_name){
	if ($i == 0){
		$pos1=$pos{$sorted_name[$i][0]};
		$pos2=($pos{$sorted_name[$i+1][0]}+$pos{$sorted_name[$i][1]})/2;
	}
	elsif ($i == $#sorted_name){
		$pos1=($pos{$sorted_name[$i][0]}+$pos{$sorted_name[$i-1][1]})/2;
		$pos2=$pos{$sorted_name[$i][1]};
	}
	else{
		$pos1=($pos{$sorted_name[$i][0]}+$pos{$sorted_name[$i-1][1]})/2;
		$pos2=($pos{$sorted_name[$i+1][0]}+$pos{$sorted_name[$i][1]})/2;
	}
	$distense=$pos2-$pos1;
	$count++;
	print $out ("$count\t$sorted_name[$i][0]\t$sorted_name[$i][1]\t$distense\n");
}

#compute the space between each set;
foreach(0..$#sorted_name-1){
	$space=$pos{$sorted_name[$_+1][0]}-$pos{$sorted_name[$_][1]};
	print $out_space (($_+1)."\t".($_+2)."\t$space\n");
}

#####################################################
#print the set whitch is sorted by the physicle distance
my %name_sort_by_phy;
foreach(0..$#sorted_name){
	$name_sort_by_phy{$sorted_name[$_][0]."\t".$sorted_name[$_][1]}=$pos{$sorted_name[$_][0]};
}
@name_phy=sort {$name_sort_by_phy{$a} <=> $name_sort_by_phy{$b}} keys %name_sort_by_phy;
my $count=1;
foreach (@name_phy){
	($name1,$name2)=split /\t/;
	print $out_set_phy ($count."\t$name1\t$pos{$name1}\n".$count++."\t$name2\t$pos{$name2}\n");
}
#####################################################
#print all the sets which are headed by selected name
my $flag = 0;
foreach my $i (0..$#sorted_name){
	my $head = $sorted_name[$i][0];
	my $tail = $sorted_name[$i][1];
	my $gene_pos = $gene_dis{$head};
	foreach (@name_set){
		if ($_ eq $head){
			print $out_all ("$_\t$pos{$_}\t$gene_dis{$head}\n");
			$flag = 1;
		}
		elsif ($_ ne $head && $flag == 1){
			print $out_all ("$_\t$pos{$_}\t$gene_dis{$head}\n");
		}
		if ($_ eq $tail){
			#print $out_all ("$_\t$pos{$_}\t$gene_dis{$head}\n");
			$flag = 0;
			last;
		}
	}
}
