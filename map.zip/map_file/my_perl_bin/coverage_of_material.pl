#!/usr/bin/perl
#count the numbers of the materials for each LM(the length)
#need one input file:the first line is the position and the others are the snps' type

mkdir "coverage_of_material";

my $fname = shift @ARGV;

open my $fin,'<',$fname or die;
$fname =~ /([^\/]*)$/;
$fname = $1;
$fname = substr $fname,0,4;
unlink "coverage_of_material/".$fname."_counts_of_materials";
open my $out,'>>',"coverage_of_material/".$fname."_counts_of_materials" or die;

my $line = <$fin>;
chomp $line;
my @pos = split /\t/,$line;

my $L=5000000;
my @result,@temp;
$result[int $pos[-1]/$L] = 0;
$temp[int $pos[-1]/$L] = 0;
while (<$fin>){
	chomp;
	@line = split /\t/;
	shift ;
	foreach (0..$#line){
		if ($line[$_] == 3){
			$temp[int $pos[$_]/$L] = 1;
			#print $_."\t";
		}
	}
	map {$result[$_] = $result[$_] + $temp[$_];$temp[$_] = 0;} 0..$#result;
	#@result[0..$#result] = @result[0..$#result] + @temp[0..$#temp];
}
map {print $out (($_+1)."\t$result[$_]\n")} 0..$#result;
