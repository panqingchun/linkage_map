#!/usr/bin/perl
#compute the data for drawing the map
#need two files:
#1.the set name which is sorted by physical distance,such as 1 name1 \n 1 name2 \n 2name3.....
#2.the first name of the set which is sorted by the genatic distance.

mkdir "ratio_of_gene_and_phy/";
$fname1 = shift @ARGV;
$fname2 = shift @ARGV;
my $win_size = shift @ARGV;
if ($win_size == 0){
	$win_size = 1000000;
}

open my $fh1,'<',$fname1 or die;
open my $fh2,'<',$fname2 or die;
$fname1 =~ /([^\/]*)$/;
$fname1 = $1;
$fname1 = substr $fname1,0,4;
open my $out , '>' , "ratio_of_gene_and_phy/".$fname1."_ratio" or die;

while(<$fh1>){
	chomp;
	push @phy,[split /\t/];
}
while(<$fh2>){
	chomp;
	push @gene,[split /\t/];
}

@phy = sort{$$a[1] <=> $$b[1]} @phy;
#生成完整的基因标记数组
my @gene1;
for (my $i=0 ; $i<@gene ; $i++){
	my $set = -1;
	my $gene_name = $gene[$i][0];
	for (my $j = 0; $j< @phy ; $j++){
		if ($phy[$j][0] eq $gene_name){
			$set = $phy[$j][2];
		}
		if ($set eq $phy[$j][2]){
			push @gene1,[($phy[$j][0],$gene[$i][1])];
		}
	}
}

for (my $i=0 ; $i<@gene1 ; $i++){
	$gene_name_idx{$gene1[$i][0]} = $i;
}

my @phy1;
for (my $i=0 ; $i<@phy ; $i++){
	if ($phy[$i][0] eq $gene1[$i][0]){
		push @phy1 , [($phy[$i][0],$phy[$i][1])];	
	}
}

my $win_curr = $win_size;
my $first = 0;
print $out ("window\tratio\n");
for (my $i=1 ; $i < @phy1 ; $i++){
	if (($phy1[$i][1]+$phy1[$i-1][1])/2 >= $win_curr){
		my $last = $gene1[$gene_name_idx{$phy1[$i][0]}][1];
		my $ratio = ($last - $first)/($win_size/1000000);
		print $out (($win_curr/1000000)."\t$ratio\n");
		$win_curr+=$win_size;
		$first = $last;
	}
}
my $ratio = ($gene1[$gene_name_idx{$phy1[-1][0]}][1] - $first)/($win_size/1000000);

print $out (($win_curr/1000000)."\t$ratio\n");

