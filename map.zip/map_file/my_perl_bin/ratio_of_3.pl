#!/usr/bin/perl
#计算杂合的覆盖率

mkdir "ratio_of_3/";
my $fname = shift @ARGV;
my $win_size = shift @ARGV;
if ($win_size == 0){
	$win_size = 1000000;
}
print $win_size."\n";
open my $fi , '<' , $fname or die;

$fname =~ /([^\/]*)$/;
$fname = $1;
$fname = substr $fname,0,4;

open my $out , '>' , "ratio_of_3/".$fname or die;

my $pos = <$fi>;
chomp $pos;
my @pos = split /\t/,$pos;
shift @pos;


my $num_of_mat = 0;
my @length;

while(<$fi>){

	chomp;
	my @line = split /\t/;
	shift @line;
	my $start = -1;
	my $end = -1;
	my $count = 0;
	my $win_curr = $win_size;
	$num_of_mat++;
	for (my $i=0 ; $i<@line ; $i++){
		if ($pos[$i]>$win_curr){
			if ($start != -1 && $end != -1){
				$length[$count] = $pos[$end] - $pos[$start];
			}
			$start = -1;
			$end = -1;
			$count++;
			$win_curr+=$win_size;
		}
		if ($line[$i] == 3 && $start == -1){
			$start = $i;
		}elsif ($line[$i] == 3 && $start != -1){
			$end = $i;
		}elsif ($line[$i] != 3 && $start != -1 && $end != -1){
			$length[$count] = $pos[$end] - $pos[$start];
			$start = -1;
			$end = -1;

		}elsif ($line[$i] != 3 && $start != -1 && $end == -1){
			$start = -1;
		}
	}
}

print $out ("window\tratio\n");
for (my $i = 0; $i<@length ; $i++){
	my $ratio = $length[$i]/($num_of_mat * $win_size)*100;
	print $out (($win_size*($i+1)/1000000)."\t".$ratio."%\n");
}


