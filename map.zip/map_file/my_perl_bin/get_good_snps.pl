#!/usr/bin/perl
#compute the data for drawing the map
#need two files:
#1.the set name which is sorted by physical distance,such as 1 name1 \n 1 name2 \n 2name3.....
#2.the first name of the set which is sorted by the genatic distance.

mkdir "good_snps/";
$fname1 = shift @ARGV;
$fname2 = shift @ARGV;
print $fname1."\n";
open my $fh1,'<',$fname1 or die;
open my $fh2,'<',$fname2 or die;
$fname1 =~ /([^\/]*)$/;
$fname1 = $1;
$fname1 = substr $fname1,0,4;
$out1="good_snps/left_data";
$out2="good_snps/left_data";


open my ($out_phy) ,'>>',$out1 or die;
open my ($out_gene) ,'>>',$out2 or die;

while(<$fh1>){
	chomp;
	push @phy,[split /\t/];
}
while(<$fh2>){
	chomp;
	push @gene,[split /\t/];
}

my @phy1;
my $set = $phy[0][2];
my @tmp1,%name_h,%name_h1,%gene_name_idx,%phy_name_idx;
my $count = 1;
for (my $i=0;$i<@phy;$i++){
	$phy_name_idx{$phy[$i][0]} = $i;
	if ($phy[$i][2] == $set){
		push @tmp1, [($phy[$i][0],$phy[$i][1],0)];
		$name_h{$phy[$i][0]} = $tmp1[0][0];
		$name_h1{$phy[$i][0]} = 0;
		#print $tmp1[0][0]."\n";
	}else{
		push @phy1, [@tmp1];
		@tmp1 = undef;
		shift @tmp1;
		$set = $phy[$i][2];
		$i--;
	}
}
@phy = sort{$$a[1] <=> $$b[1]} @phy;
for (my $i=0;$i<@phy;$i++){
	$phy_name_idx{$phy[$i][0]} = $i;
}
#生成完整的基因标记数组
my @gene1;
for (my $i=0 ; $i<@gene ; $i++){
	my $set = -1;
	my $gene_name = $gene[$i][0];
	for (my $j = 0; $j< @phy ; $j++){
		if ($phy[$j][0] eq $gene_name){
			$set = $phy[$j][2];
		}
		if ($set eq $phy[$j][2]){
			push @gene1,[($phy[$j][0],$gene[$i][1])];
		}
	}
}
for (my $i=0 ; $i<@gene1 ; $i++){
	$gene_name_idx{$gene1[$i][0]} = $i;
}

$n1 = @phy;
$n2 = @gene1;
print "$n1\n$n2\n";
for (my $i=0 ; $i<@phy ; $i++){

	if ($name_h{$phy[$i][0]} eq $phy[$i][0] || $name_h{$gene1[$i][0]} eq $gene1[$i][0]){
		#print $out_phy ("$phy[$i][0]\t$phy[$i][1]\n");
		#print $out_gene ("$gene1[$i][0]\t$gene1[$i][1]\n");
		#$name_h1{$phy[$i][0]} = 1;
		#$name_h1{$gene1[$i][0]} = 1;
		next;
	}
	#if ($name_h{$phy[$i][0]} ne $name_h{$gene1[$i][0]}){
	my $gene_idx = $gene_name_idx{$phy[$i][0]};
	my $phy_idx = $phy_name_idx{$gene1[$i][0]};
	#print $phy_idx."\t".$name_h{$gene1[$gene_idx-1][0]}."\n";
	if ($name_h{$phy[$i][0]} ne $name_h{$gene1[$gene_idx-1][0]}  )
	{
		$phy[$i][3] = 1;
		$gene1[$i][2] = 1;
		$name_h1{$phy[$i][0]} = 1;
		$name_h1{$gene1[$i][0]} = 1;
		#print $out_phy ("$phy[$i][0]\t$phy[$i][1]\n");
		#print $out_gene ("$gene1[$i][0]\t$gene1[$i][1]\n");
		#print "$phy[$i][0]\t$gene1[$i][0]\n";
	}
}


for (my $i = 0; $i <@phy ; $i++){
	if ($name_h1{$phy[$i][0]} !=1){
		print $out_phy ("$phy[$i][0]\t$fname1\t$phy[$i][1]\n");
	}
}

=top
|||| $name_h{$phy[$i][0]} ne $name_h{$gene1[$gene_idx+1][0]}
		$name_h{$gene1[$i][0]} ne $name_h{$phy[$phy_idx-1][0]} || $name_h{$gene1[$i][0]} ne $name_h{$phy[$phy_idx+1][0]}
=cut
