#!/usr/bin/perl


@num = map { sprintf "%02d",$_} 1..10;
map {system 'touch ch'.$_.'_gene_all ch'.$_.'_gene_pos ch'.$_.'_map ch'.$_.'_pos ch'.$_.'_set'} @num;
#map {system 'rm ch'.$_.'_gene_all ch'.$_.'gene_pos ch'.$_.'_map ch'.$_.'pos ch'.$_.'set'} @num;
