#!/usr/bin/perl

@num = map { sprintf "%02d",$_} 1..10;
map {system './Transpose.pl ch'.$_.'_gene_all'}@num;
map {system './fill_the_map.pl ch'.$_.'_gene_all.tr'} @num;
map {unlink 'ch'.$_.'_gene_all.tr'} @num;
map {system './ratio_of_3.pl result_map/ch'.$_.'_gene_all.tr_map_result 5000000'} @num;

map {system './ratio_of_gene_and_phy.pl result_distance/set_name_all/ch'.$_.'_name_all  ch'.$_.'_gene_pos 5000000';} @num;
