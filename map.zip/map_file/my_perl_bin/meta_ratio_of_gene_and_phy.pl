#!/usr/bin/perl


@num = map { sprintf "%02d",$_} 1..10;
map {system './ratio_of_gene_and_phy.pl result_distance/set_name_all/ch'.$_.'_name_all  ch'.$_.'_gene_pos';} @num;
