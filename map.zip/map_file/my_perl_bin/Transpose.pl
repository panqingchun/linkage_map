#!/usr/bin/perl
#use to transpose the big files(which is very regular)

my $fname=shift @ARGV;
unlink $fname.".tr";
open my $fh,'<',$fname or die;
open my $out,'>>',$fname.".tr" or die;

my @matrix;
while(<$fh>){
	chomp;
	push @matrix,[split /\t/]; 
}
foreach my $i (0..$#{$matrix[0]}){
	foreach my $j (0..$#matrix){
		print $out ($matrix[$j][$i]."\t");
	}
	print $out ("\n");
}
