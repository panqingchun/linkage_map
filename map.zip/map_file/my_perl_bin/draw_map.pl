#!/usr/bin/perl

use GD;
use GD::Text::Align;

mkdir "map/";

my $fname1 = shift @ARGV;
my $fname2 = shift @ARGV;

open my $phy_in,'<',$fname1 or die;
open my $gene_in,'<',$fname2 or die;
$fname1 =~ /([^\/]*)$/;
$fname1 = $1;
my $title=substr($fname1,0,4);
open my $out,'>',"map/$title.png";
open my $out_s,'>',"map/$title\_statistic";

my $L=10;
my $X1=190;
my $X2=240;
my $X=420;

while(<$gene_in>){
	if ($_ eq ""){next;}
	chomp;
	($name,$pos) = split /\t/;
	push @gene,[$name,$pos];
}
@gene = sort {$$a[1] <=> $$b[1]} @gene;
while(<$phy_in>){
	if ($_ eq ""){next;}
	chomp;
	($name,$pos) = split /\t/;
	push @phy,[$name,$pos];
}
@phy = sort {$$a[1] <=> $$b[1]} @phy;
@idx_phy=(1..@phy);

foreach my $i (0..$#gene){
	foreach my $j (0..$#phy){
		if ($gene[$i][0] eq $phy[$j][0]){
			push @idx_gene, $j+1;
			next;
		}
	}
}

sub statistic{
foreach my $i(0..$#gene){
	if ($i >= $idx_gene[$i]){
		$max = $i+1;
		$min = $idx_gene[$i];
	}
	else{
		$min = $i+1;
		$max = $idx_gene[$i];
	}
	$L = $max-$min;
	$pos1 = $phy[$min-1][1];
	$pos2 = $phy[$max-1][1];
	if ($L >=2 && $L <=9 && $pos1>$old_pos){
		$old_pos = $pos2;
		print $out_s ("$title\t$phy[$min][1]\t$phy[$max][1]\t".($phy[$max][1]-$phy[$min][1])."\n");
	}
}
}


my $N=$X;
my $M=$#gene*$L;
$im = new GD::Image($N,$M+40);
$white = $im->colorAllocate(255,255,255);
$black = $im->colorAllocate(0,0,0);

$im->line($X1,20,$X1,$M+20,$black);
$im->line($X2,20,$X2,$M+20,$black);

my $align = GD::Text::Align->new($im,color=>$black,);
#$align->set_font('/usr/share/fonts/abattis-cantarell/Cantarell-Regular.otf', 10) or die;
foreach (0..$#idx_gene){
	$im->line($X1,$idx_gene[$_]*$L+10,$X2,$idx_phy[$_]*$L+10,$black);
	$align->set_halign('left');
	$align->set_text($gene[$_][0]."($gene[$_][1])");
	$align->draw($X2+3,($_+1)*$L+17,0);

	$align->set_halign('right');
	$lenth=sprintf "%0.2f",$phy[$_][1]/1000000;
	$align->set_text($phy[$_][0]."($lenth)");
	$align->draw($X1-3,($_+1)*$L+17,0);
}
$align->set_halign('center');
#$align->set_font('/usr/share/fonts/abattis-cantarell/Cantarell-Regular.otf', 12) or die;
$align->set_text($title);
$align->draw($X/2,15);

&statistic();

binmode STDOUT;
print $out $im->png;
