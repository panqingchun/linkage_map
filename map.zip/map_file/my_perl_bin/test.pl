#!/usr/bin/perl -w

use File::Path;

mkpath "testdd/rrr/eee" or die;

open my ($data3) ,'<', "ch01_gene_pos" or die;
@selected_name=<$data3>;
map {chomp} @selected_name;
@selected_name = map {(split /\t/,$_)[1]} @selected_name;
#print join "\n",@selected_name;

@num = map { sprintf "%02d",$_} 1..10;
#print join "\n",@num;


